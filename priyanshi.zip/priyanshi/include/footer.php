<div id="contact">
    <img id="k" src="images/krishnawhite.jpg">
    <img id="s" src="images/strip.png">
    <div id="end">
      <footer class="footer-distributed">
        <div class="footer-left">
          <h3>Krishna <span>&</span> Me</h3>
      
          <p class="footer-links">
            <a href="#">Home</a>
            ·
            <a href="#">About Us</a>
            ·
            <a href="#">Blog</a>
            ·
            <a href="#">Events</a>
            ·
            <a href="#">Projects</a>
            ·
            <a href="#">Contact</a>
          </p>
      
          <p class="footer-company-name">&copy; 2020</p>
        </div>
      
        <div class="footer-center">
          <!-- <div>
            <i class="fa fa-map-marker"></i>
            <p>
              <span>Anna Nagar slums,Rachna Nagar,Bhopal</span> Madhya Pradesh,
              India
            </p>
          </div> -->
      
          <div>
            <i class="fa fa-phone"></i>
            <p>+91 9837539999</p>
          </div>
      
          <div>
            <i class="fa fa-envelope"></i>
            <p>
              <a href="#" style="color: white;">krishnaandme@gmail.com</a>
            </p>
          </div>
        </div>
      
        <div class="footer-right">
          <p class="footer-company-about">
            <span>About Us</span>
            Aaroha is a youth organization which works for the upliftment of the
            underprivileged children.
          </p>
      
          <div class="footer-icons">
            <a href="https://www.facebook.com/aaroha.youthorg/">
              <img src="https://img.icons8.com/nolan/40/facebook-new.png"
            /></a>
            <a href="#"
              ><img src="https://img.icons8.com/nolan/40/twitter.png"
            /></a>
            <a href="https://www.facebook.com/aaroha.youthorg/"
              ><img src="https://img.icons8.com/nolan/40/instagram-new.png"
            /></a>
          </div>
        </div>
      </footer>
    </div>
    </div>
  <!--Modal Details-->    
 
         <!-- AniJS core library -->
     <script src="https://anijs.github.io/lib/anijs/anijs-min.js"></script> 
      
     <!-- Include to use $addClass, $toggleClass or $removeClass -->
     <script src="https://anijs.github.io/lib/anijs/helpers/dom/anijs-helper-dom-min.js"></script>
    
     
     <script src="https://anijs.github.io/lib/anijs/helpers/scrollreveal/anijs-helper-scrollreveal-min.js"></script>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>  
        <script  src="https://code.jquery.com/jquery-3.4.1.js"></script>
        <script>
            $(document).on('click', '[data-toggle="lightbox"]', function(event) {
                        event.preventDefault();
                        $(this).ekkoLightbox();
                    });
       
       
        
        
            function add_to_cart(){
                jQuery('#modal_errors').html("");
                var size = jQuery('#size').val();
                var quantity = jQuery('#quantity').val();
                var error ="";
                var data = jQuery('#add_product_form').serialize();
                if(size == '' || quantity=='' || quantity==0){
                  error=error+'<p class="text-danger text-center">You must choose a size and quantity.</p>';
                 jQuery('#modal_errors').html(error);
                  return;
                }
                else{
                  jQuery.ajax({
                    url:'cart.php',
                    method:'post',
                    data:data,
                    success : function(){
                      location.reload();
                    },
                    error : function(){alert("Something went wrong");}
                  });
                }

            }
           
           function detailsmodal(id){
             alert(id);
             var data = {"id":id};
             jQuery.ajax({
               url:'include/detailmodal.php',
               method:"post",
               data:data,
               success:function(data){
                 jQuery('body').append(data);
                 jQuery('#details-modal').modal('toggle');
               },
               error:function(){
                 alert("Something went wrong!");
               }
             });
           }

            </script>


      </body>
      </html>