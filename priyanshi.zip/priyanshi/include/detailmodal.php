
<?php 
require_once('priyanshi/core/init.php');
$id = $_POST['id'];
$id = (int)$id;
$sql = "SELECT * FROM deity_products WHERE id = '$id'";
$result = mysqli_query($con,$sql);
$product = mysqli_fetch_assoc($result);
?>


<?php
ob_start();
?>







<div class="modal fade details-1" id="details-modal" tabindex="-1" role="dialog" aria-labelledby="details-1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title text-center"><?php echo $product['Name'] ?></h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          
        </div>
        <div class="modal-body">
          <div class="container-fluid">
            <div class="row">
              <span id="modal_errors" ></span>
               </div>
              <div class="row">
                <div class="col-sm-6">
                    <div class="center-block">
                        <img src="<?php echo $product['Image'] ?>" class="details img-responsive">
                    </div>
                </div>
                <div class="col-sm-6">
                    <h4>Description</h4>
                    <p>Welcome to Divyshringar, a divine hub. We at Divyshringar aim to serve God, by serving men. </p>
                    <hr />
                    <h4>Features</h4>
                    <ul>
                    <li>Material:<?php echo $product['Material'] ?></li>
                    <li>Color:<?php echo $product['Color'] ?></li>
                    <li>Style:<?php echo $product['Style'] ?></li>
                    </ul>

                    <hr />
                    <p>Price: Rs <?php echo $product['Price'] ?></p> 
                    <form action="cart.php" method="POST" id="add_product_form">
                    <input type="hidden" name="product_id"  value="<?php echo $product['deity_id'] ?>">
                      <input type="hidden" name="available" id="available" value="">
                      Quantity:<input type="number" id="quantity" name="quantity">
                      <br>
                      <br>
                      Size:<select name="size" id="size">
                        <option value="S">S</option>
                        <option value="M">M</option>
                        <option value="L">L</option>
                      </select>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button onclick="add_to_cart();return false;" class="btn btn-warning"><span class="glyphicon glyphicon-shopping-ca rt"><i class="fa fa-shopping-cart"></i></span> Add To Cart</button>
        </div>
      </div>
    </div>
  </div>
</div> 
<?php echo ob_get_clean();?>


  
