<?php

ob_start();
function display_errors($errors){
    $display = '<ul class="bg-danger">';
    foreach($errors as $error){
        $display .= '<li style="color:white;">'.$error.'</li>';
    }
    $display .='</ul>';
    return $display;
}
function sanitize($dirty){
    return htmlentities($dirty,ENT_QUOTES,"UTF-8");
}
function login($user_id){
    $_SESSION['SBUser'] = $user_id;
    global $con;
    $date = date("Y-M-D H:i:s");
    mysqli_query($con,"UPDATE srs SET last_login ='$date' WHERE id='$user_id'");
    $_SESSION['success_flash']="You are now logged in!";
    header('Location: index.php');
  }
 
  function is_logged_in(){
    if(isset($_SESSION['SBUser']) && $_SESSION['SBUser']>0){
      return true;
    }
    return false;
  }
 
  function login_error_redirect(){
    $_SESSION['error_flash'] = "You must be logged in to access that page";
    header('Location: login.php');
  }

?>