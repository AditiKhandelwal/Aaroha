<div class="modal fade details-1" id="details-1" tableindex="1" role="dialog" aria-labelby="details-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
           <button class="close" type="button" data-dismiss="modal" aria-label="Close">
               <span aria-hidden ="true">&times;</span>
</button>
<h4 class="modal-title text-center">Poshak</h4>
        </div>  
        <div class="modal-body">
            <div class="container-fluid">
              <div class="row">
                  <div class="col-sm-6">
                      <div class="center-block">
                          <img src="pro1.jpg" class="details img-responsive">
                      </div>
                  </div>
                  <div class="col-sm-6">
                      <h4>Details</h4>
                      <p>These poshak are amazing. You must buy this.Get them while they last.</p>
                      <hr />
                      <p>Price: Rs 200</p> 
                      
                  </div>
              </div>
          </div>
        </div>  
    </div>
</div>
</div>

