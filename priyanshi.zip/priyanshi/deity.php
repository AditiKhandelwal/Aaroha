<?php

require_once ('core/init.php');
if(!is_logged_in()){
  login_error_redirect();
}



$sql ="SELECT * FROM deity_products";
$products =  mysqli_query($con,$sql);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Priyanshi</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
    <title>Hello, world!</title>

    <link rel="stylesheet" href="https://anijs.github.io/lib/anicollection/anicollection.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link
    rel="stylesheet"
    href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css"
  />
  <link
    href="http://fonts.googleapis.com/css?family=Cookie"
    rel="stylesheet"
    type="text/css"
  />
   <style>
      #strip {
       background-color: #0482d1;
       height:50px;
     }
     #name {
        height:100px;
        margin-bottom: 70px;
     }
     #name h1 {
             padding-top:40px;
             
             color:rgb(50, 101, 189);
             text-align: center;
             font-size:80px;
             float: left;
     }
     #name img {
       width: 140px;
       height: 160px;
       float: left;
       padding-top: 30px;
       margin-left: 450px;
       
     }
     #end {
              background-color:#0482d1;
             
              height:300px;
            }
            #contact {
              margin-top: 100px;
            }
            #contact #k {
              width:300px;
              height: 300px;
             margin-left: 600px;
            }
            #contact #s {
              width:100%;
              height:100px;
            }
            #about img {
              width:400px;
              height: 525px;
              float:right;
              
            }
            .footer-distributed {
  
  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
  box-sizing: border-box;
  width: 100%;
  text-align: left;
  font: bold 16px sans-serif;
  height:300px;
  padding: 55px 50px;
 
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right {
  display: inline-block;
  vertical-align: top;
}

.footer-distributed .footer-left {
  width: 40%;
}

.footer-distributed h3 {
  color: #ffffff;
  font: normal 36px "Cookie", cursive;
  margin: 0;
}

.footer-distributed h3 span {
  color: black;
}

.footer-distributed .footer-links {
  color: #ffffff;
  margin: 20px 0 12px;
  padding: 0;
}

.footer-distributed .footer-links a {
  display: inline-block;
  line-height: 1.8;
  text-decoration: none;
  color: inherit;
}

.footer-distributed .footer-company-name {
  color: #8f9296;
  font-size: 14px;
  font-weight: normal;
  margin: 0;
}

.footer-distributed .footer-center {
  width: 35%;
}

.footer-distributed .footer-center i {
  background-color: black;
  color: whitesmoke;
  font-size: 25px;
  width: 38px;
  height: 38px;
  border-radius: 50%;
  text-align: center;
  line-height: 42px;
  margin: 10px 15px;
  vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope {
  font-size: 17px;
  line-height: 38px;
}

.footer-distributed .footer-center p {
  display: inline-block;
  color: whitesmoke;
  vertical-align: middle;
  margin: 0;
}

.footer-distributed .footer-center p span {
  display: block;
  font-weight: normal;
  font-size: 14px;
  line-height: 2;
}

.footer-distributed .footer-center p a {
  color: black;
  text-decoration: none;
}

.footer-distributed .footer-right {
  width: 20%;
}

.footer-distributed .footer-company-about {
  line-height: 20px;
  color: #d1d1d8;
  font-size: 13px;
  font-weight: normal;
  margin: 0;
}

.footer-distributed .footer-company-about span {
  display: block;
  color: whitesmoke;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 20px;
}

.footer-distributed .footer-icons {
  margin-top: 25px;
}

.footer-distributed .footer-icons a {
  width: 35px;
  height: 35px;
  cursor: pointer;

  font-size: 20px;
  text-align: center;
  line-height: 35px;

  margin-right: 3px;
  margin-bottom: 5px;
}

@media (max-width: 880px) {
  .footer-distributed {
    font: bold 14px sans-serif;
  }

  .footer-distributed .footer-left,
  .footer-distributed .footer-center,
  .footer-distributed .footer-right {
    display: block;
    width: 100%;
    margin-bottom: 40px;
    text-align: center;
  }

  .footer-distributed .footer-center i {
    margin-left: 0;
  }
  .main {
    line-height: normal;
    font-size: auto;
  }
}

.row img {
  width: 200px;
  height: 200px;
}
.row {
  padding:20px;
}

#box {
  height:auto;
  
}


       </style>
  </head>
  <body>
  <div id="strip">

  </div>
  <div id="name">
    <img src="images/krishnawhite.jpg">
      <h1>Krshna & Me</h1>
  </div>

  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="padding-left: 120px;padding-right: 20px;">
        <li class="nav-item active" style="padding-right: 20px;">
          <a class="nav-link" href="#">HOME <span class="sr-only">(current)</span></a>
        </li>
        
        <li class="nav-item active dropdown"  style="padding-right: 20px;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            IDOLS
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
           


              
            <a class="dropdown-item" href="#">Brass Idols</a>
            <div class="dropdown-divider"></div>
            
         
          
            <a class="dropdown-item" href="#">Marble Idols</a>
            <div class="dropdown-divider"></div>
           
          
            <a class="dropdown-item" href="#">Black Hand Printed Idols</a>
            <div class="dropdown-divider"></div>

            <a class="dropdown-item" href="#">Ashtdhatu Idols</a>
            <div class="dropdown-divider"></div>
 
            <a class="dropdown-item" href="#">Silver Idols</a>
          

          </div>
        </li>
        <li class="nav-item active dropdown"  style="padding-right: 20px;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              POSHAKS
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
  
  
                
              <a class="dropdown-item" href="#">Summer Season Poshak</a>
              <div class="dropdown-divider"></div>
              
           
            
              <a class="dropdown-item" href="#">Winter Season Poshak</a>
              <div class="dropdown-divider"></div>
             
            
              <a class="dropdown-item" href="#">Spring Season Poshak</a>
              <div class="dropdown-divider"></div>
  
              <a class="dropdown-item" href="#">Autumn Season Poshak</a>
              <div class="dropdown-divider"></div>

              <a class="dropdown-item" href="#">Leela Based Poshak</a>
              <div class="dropdown-divider"></div>
   
              <a class="dropdown-item" href="#">Festival Special Poshak</a>
            
  
            </div>
          </li>
          <li class="nav-item active dropdown"  style="padding-right: 20px;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              ACCESSORIES
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
  
  
                
              <a class="dropdown-item" href="#">Mukut Mala</a>
              <div class="dropdown-divider"></div>
              
           
            
              <a class="dropdown-item" href="#">Turban</a>
              <div class="dropdown-divider"></div>
             
            
              <a class="dropdown-item" href="#">Hair</a>
              <div class="dropdown-divider"></div>
  
              <a class="dropdown-item" href="#">Bangle</a>
              <div class="dropdown-divider"></div>

              <a class="dropdown-item" href="#">Tilak</a>
              <div class="dropdown-divider"></div>
   
              <a class="dropdown-item" href="#">Earrings</a>
            
  
            </div>
          </li>



        <li class="nav-item active"  style="padding-right: 20px;">
          <a class="nav-link" href="#">OTHERS <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="#">CONTACT <span class="sr-only">(current)</span></a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </nav>
<br>
<h1 style="text-align: center;">All Deity Products</h1>
<br>
<div class="row">
<div class="col-md-2">
  <div class="list-group">
    <a href="#" class="list-group-item list-group-item-primary ">
      IDOLS
    </a>
   
    <a href="#" class="list-group-item list-group-item-action">Brass Idols</a>
    <a href="#" class="list-group-item list-group-item-action">Marble Idols</a>
    <a href="#" class="list-group-item list-group-item-action">Black Hand Printed Idols</a>
    <a href="#" class="list-group-item list-group-item-action">Ashtdhatu Idols</a>
    <a href="#" class="list-group-item list-group-item-action">Silver Idols</a>
  </div>
  <br>
  <div class="list-group">
    <a href="#" class="list-group-item list-group-item-primary ">
      POSHAKS
    </a>
    <a href="#" class="list-group-item list-group-item-action">Winter Season Poshak</a>
    <a href="#" class="list-group-item list-group-item-action">Summer Season Poshak</a>
    <a href="#" class="list-group-item list-group-item-action">Spring Season Poshak</a>
    
  </div>
  <br>
  <div class="list-group">
    <a href="#" class="list-group-item list-group-item-primary">
      Cras justo odio
    </a>
    <a href="#" class="list-group-item list-group-item-action">Dapibus ac facilisis in</a>
    <a href="#" class="list-group-item list-group-item-action">Morbi leo risus</a>
    <a href="#" class="list-group-item list-group-item-action">Porta ac consectetur ac</a>
    <a href="#" class="list-group-item list-group-item-action disabled" tabindex="-1" aria-disabled="true">Vestibulum at eros</a>
  </div>
</div>

<div class="col-md-10" style="padding-left: 60px;">
  <div id="box" class="shadow p-3 mb-5 bg-white rounded">
    <h2>IDOLS</h2>
    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
  </div>

  
  <div class="row">
    <?php while($pro = mysqli_fetch_assoc($products)) : ?>
    <div class="col-md-4">
      <img src="<?php echo $pro['Image'] ?>">
      <p><?php echo $pro['Name'] ?></p>
      <p>Price: Rs <?php echo $pro['Price'] ?></p>
      <button type="button" class="btn btn-success"  onclick=" detailsmodal(<?php echo $pro['deity_id'] ?>)">Details</button>
     
    </div>
 <?php endwhile; ?>
  
  
  </div>



</div>


</div>
<script  src="https://code.jquery.com/jquery-3.4.1.js"></script>
<script>
   function detailsmodal(id){
             
             var data = {"id":id};
             jQuery.ajax({
               url:'include/detailmodal.php',
               method:"post",
               data:data,
               success:function(data){
                 jQuery('body').append(data);
                 jQuery('#details-modal').modal('toggle');
               },
               error:function(){
                 alert("Something went wrong!");
               }
             });
           }

  </script>
     
      <?php include 'include/detailmodal.php'; ?>
      
      <?php include 'include/footer.php'; ?>