<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/priyanshi/core/init.php';

$password =((isset($_POST['password']))?sanitize($_POST['password']):'');

$password = trim($password);
$hashed =md5($password);
$email =((isset($_POST['email']))?sanitize($_POST['email']):'');
$email = trim($email);
$errors = array();



?>




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Priyanshi</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
    <title>Hello, world!</title>

    <link rel="stylesheet" href="https://anijs.github.io/lib/anicollection/anicollection.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link
    rel="stylesheet"
    href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css"
  />
  <link
    href="http://fonts.googleapis.com/css?family=Cookie"
    rel="stylesheet"
    type="text/css"
  />
   <style>
   #strip {
       background-color: #0482d1;
       height:50px;
     }
     #name {
        height:100px;
        margin-bottom: 70px;
     }
     #name h1 {
             padding-top:40px;
             
             color:rgb(50, 101, 189);
             text-align: center;
             font-size:80px;
             float: left;
     }
     #name img {
       width: 140px;
       height: 160px;
       float: left;
       padding-top: 30px;
       margin-left: 450px;
       
     }
     #end {
              background-color:#0482d1;
             
              height:300px;
            }
            #contact {
              margin-top: 100px;
            }
            #contact #k {
              width:300px;
              height: 300px;
             margin-left: 600px;
            }
            #contact #s {
              width:100%;
              height:100px;
            }
            #about img {
              width:400px;
              height: 525px;
              float:right;
              
            }
     .footer-distributed {
  
  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
  box-sizing: border-box;
  width: 100%;
  text-align: left;
  font: bold 16px sans-serif;
  height:300px;
  padding: 55px 50px;
 
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right {
  display: inline-block;
  vertical-align: top;
}

.footer-distributed .footer-left {
  width: 40%;
}

.footer-distributed h3 {
  color: #ffffff;
  font: normal 36px "Cookie", cursive;
  margin: 0;
}

.footer-distributed h3 span {
  color: black;
}

.footer-distributed .footer-links {
  color: #ffffff;
  margin: 20px 0 12px;
  padding: 0;
}

.footer-distributed .footer-links a {
  display: inline-block;
  line-height: 1.8;
  text-decoration: none;
  color: inherit;
}

.footer-distributed .footer-company-name {
  color: #8f9296;
  font-size: 14px;
  font-weight: normal;
  margin: 0;
}

.footer-distributed .footer-center {
  width: 35%;
}

.footer-distributed .footer-center i {
  background-color: black;
  color: whitesmoke;
  font-size: 25px;
  width: 38px;
  height: 38px;
  border-radius: 50%;
  text-align: center;
  line-height: 42px;
  margin: 10px 15px;
  vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope {
  font-size: 17px;
  line-height: 38px;
}

.footer-distributed .footer-center p {
  display: inline-block;
  color: whitesmoke;
  vertical-align: middle;
  margin: 0;
}

.footer-distributed .footer-center p span {
  display: block;
  font-weight: normal;
  font-size: 14px;
  line-height: 2;
}

.footer-distributed .footer-center p a {
  color: black;
  text-decoration: none;
}

.footer-distributed .footer-right {
  width: 20%;
}

.footer-distributed .footer-company-about {
  line-height: 20px;
  color: #d1d1d8;
  font-size: 13px;
  font-weight: normal;
  margin: 0;
}

.footer-distributed .footer-company-about span {
  display: block;
  color: whitesmoke;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 20px;
}

.footer-distributed .footer-icons {
  margin-top: 25px;
}

.footer-distributed .footer-icons a {
  width: 35px;
  height: 35px;
  cursor: pointer;

  font-size: 20px;
  text-align: center;
  line-height: 35px;

  margin-right: 3px;
  margin-bottom: 5px;
}

@media (max-width: 880px) {
  .footer-distributed {
    font: bold 14px sans-serif;
  }

  .footer-distributed .footer-left,
  .footer-distributed .footer-center,
  .footer-distributed .footer-right {
    display: block;
    width: 100%;
    margin-bottom: 40px;
    text-align: center;
  }

  .footer-distributed .footer-center i {
    margin-left: 0;
  }
  .main {
    line-height: normal;
    font-size: auto;
  }
}
#login-form {
  
  width:50%;
  height:60%;
  border:2px solid #000;
  border-radius:15px;
  box-shadow:7px 7px 15px rgba(0,0,0,0.6);
  margin:7% auto;
  padding:15px;
  background-color:#fff;
}



</style>
  </head>
  <body>
  <div id="strip">

  </div>
  <div id="name">
    <img src="images/krishnawhite.jpg">
      <h1>Krshna & Me</h1>
  </div>

<div id="login-form">
  <div>
    <?php 
    if($_POST)
    {
      //form validation
      if(empty($_POST['email'])||empty($_POST['password']))
      {
        $errors[]="You must provide email and password.";
      }
      //validate email
     // if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
       //$errors[] ='You must enter a valid email';
       
      //}
      //password is more than 6 characters
      if(strlen($password)<6)
      {
        $errors[] ='Password must be at least 6 characters.';
      }
      //check if email exist in database
      $query= mysqli_query($con,"SELECT * FROM users WHERE email='$email'");
      $user = mysqli_fetch_assoc($query);
      $userCount = mysqli_num_rows($query);
      if($userCount<1)
      {
        $errors[]="That email doesn\'t exist in our database";
      }
      if(!md5($password)==($user['password']))
      {
        $errors[]="The password does not match.Please try again";
      }
      //check for errors
      if(!empty($errors)){
        echo display_errors($errors);
      }
      else{
       //log user in 
       $user_id =$user['id'];
       login($user_id);
      }
    }
    ?>
  </div>
  <h2 class="text-center">Login</h2><hr>
  <form action="login.php" method="POST">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" name="email" id="email" class="form-control" value="<?=$email;?>">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" name="password" id="password" class="form-control" value="<?=$password;?>">
    </div>
    <div class="form-group">
      <input type="submit" class="btn btn-primary" value="Login">
    </div>
  </form>
<p class="text-right"><a href="homepage.html" alt="Home">Visit Site</a></p>
</div>








  <div id="contact">
    <img id="k" src="images/krishnawhite.jpg">
    <img id="s" src="images/strip.png">
    <div id="end">
      <footer class="footer-distributed">
        <div class="footer-left">
          <h3>Krishna <span>&</span> Me</h3>
      
          <p class="footer-links">
            <a href="#">Home</a>
            ·
            <a href="#">About Us</a>
            ·
            <a href="#">Blog</a>
            ·
            <a href="#">Events</a>
            ·
            <a href="#">Projects</a>
            ·
            <a href="#">Contact</a>
          </p>
      
          <p class="footer-company-name">&copy; 2020</p>
        </div>
      
        <div class="footer-center">
          <!-- <div>
            <i class="fa fa-map-marker"></i>
            <p>
              <span>Anna Nagar slums,Rachna Nagar,Bhopal</span> Madhya Pradesh,
              India
            </p>
          </div> -->
      
          <div>
            <i class="fa fa-phone"></i>
            <p>+91 9837539999</p>
          </div>
      
          <div>
            <i class="fa fa-envelope"></i>
            <p>
              <a href="#" style="color: white;">krishnaandme@gmail.com</a>
            </p>
          </div>
        </div>
      
        <div class="footer-right">
          <p class="footer-company-about">
            <span>About Us</span>
            Aaroha is a youth organization which works for the upliftment of the
            underprivileged children.
          </p>
      
          <div class="footer-icons">
            <a href="https://www.facebook.com/aaroha.youthorg/">
              <img src="https://img.icons8.com/nolan/40/facebook-new.png"
            /></a>
            <a href="#"
              ><img src="https://img.icons8.com/nolan/40/twitter.png"
            /></a>
            <a href="https://www.facebook.com/aaroha.youthorg/"
              ><img src="https://img.icons8.com/nolan/40/instagram-new.png"
            /></a>
          </div>
        </div>
      </footer>
    </div>
    </div>
  <!--Modal Details-->    
  <?php include 'include/detailmodal.php'; ?>
         <!-- AniJS core library -->
     <script src="https://anijs.github.io/lib/anijs/anijs-min.js"></script> 
      
     <!-- Include to use $addClass, $toggleClass or $removeClass -->
     <script src="https://anijs.github.io/lib/anijs/helpers/dom/anijs-helper-dom-min.js"></script>
    
     
     <script src="https://anijs.github.io/lib/anijs/helpers/scrollreveal/anijs-helper-scrollreveal-min.js"></script>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>  
        <script>
            $(document).on('click', '[data-toggle="lightbox"]', function(event) {
                        event.preventDefault();
                        $(this).ekkoLightbox();
                    });
        </script> 
        <script>
         $('#details-1').modal('hide');
         $('#details-2').modal('hide');
        </script>
      </body>
      </html>