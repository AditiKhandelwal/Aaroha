<?php
require_once ('core/init.php');

 if(!is_logged_in()){
    login_error_redirect();
}
 



 ?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Priyanshi</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
    <title>Hello, world!</title>

    <link rel="stylesheet" href="https://anijs.github.io/lib/anicollection/anicollection.css">
    <link
    rel="stylesheet"
    href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css"
  />
  <link
    href="http://fonts.googleapis.com/css?family=Cookie"
    rel="stylesheet"
    type="text/css"
  />
   <style>
     #strip {
       background-color: #0482d1;
       height:50px;
     }
     #name {
        height:100px;
        margin-bottom: 70px;
     }
     #name h1 {
             padding-top:40px;
             
             color:rgb(50, 101, 189);
             text-align: center;
             font-size:80px;
             float: left;
     }
     #name img {
       width: 140px;
       height: 160px;
       float: left;
       padding-top: 30px;
       margin-left: 450px;
       
     }
     .carousel-item img {
       height:700px;
     }
     #deity .design {
                width:17%;
              height:250px;
                margin: 4%;
                float:left;
                border-width: 1px;
                border-style: solid;
                border-color:navy;
            } 
            #deity {
              margin-top: 50px;
            }
           
            #devotee img {
                width:17%;
              height:250px;
                margin: 4%;
                float:left;
                border-width: 1px;
                border-style: solid;
                border-color:navy;
            } 
            #devotee {
              margin-top: 50px;
            }
            #devotee h1 {
              text-align: center;
              margin: 20px;
              color:rgb(50, 101, 189);
            }

            #donation .design {
                width:17%;
              height:250px;
                margin: 4%;
                float:left;
                border-width: 1px;
                border-style: solid;
                border-color:navy;
            } 
            #donation {
              margin-top: 50px;
            }
            #donation h1 {
              text-align: center;
              margin: 20px;
              color:rgb(50, 101, 189);
            }
          #aboutbg {
           
          }
            #about {
              margin-top: 50px;
              margin-right: 40px;
             
              
            }
            #about h1 {
              text-align: center;
              color:#0482d1;
            }
            #about p {
              font-size: 20px;
              margin-left: 100px;
             
              padding-left:20px;
              padding-right: 0px;
               border-left-width: 3px;
              border-left-color: #0482d1;
              border-left-style: solid;
              
            }
            #end {
              background-color:#0482d1;
             
              height:300px;
            }
            #contact {
              margin-top: 100px;
            }
            #contact #k {
              width:300px;
              height: 300px;
             margin-left: 600px;
            }
            #contact #s {
              width:100%;
              height:100px;
            }
            #about img {
              width:400px;
              height: 525px;
              float:right;
              
            }
            .footer-distributed {
  
  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);
  box-sizing: border-box;
  width: 100%;
  text-align: left;
  font: bold 16px sans-serif;
  height:300px;
  padding: 55px 50px;
 
}

.footer-distributed .footer-left,
.footer-distributed .footer-center,
.footer-distributed .footer-right {
  display: inline-block;
  vertical-align: top;
}

.footer-distributed .footer-left {
  width: 40%;
}

.footer-distributed h3 {
  color: #ffffff;
  font: normal 36px "Cookie", cursive;
  margin: 0;
}

.footer-distributed h3 span {
  color: black;
}

.footer-distributed .footer-links {
  color: #ffffff;
  margin: 20px 0 12px;
  padding: 0;
}

.footer-distributed .footer-links a {
  display: inline-block;
  line-height: 1.8;
  text-decoration: none;
  color: inherit;
}

.footer-distributed .footer-company-name {
  color: #8f9296;
  font-size: 14px;
  font-weight: normal;
  margin: 0;
}

.footer-distributed .footer-center {
  width: 35%;
}

.footer-distributed .footer-center i {
  background-color: black;
  color: whitesmoke;
  font-size: 25px;
  width: 38px;
  height: 38px;
  border-radius: 50%;
  text-align: center;
  line-height: 42px;
  margin: 10px 15px;
  vertical-align: middle;
}

.footer-distributed .footer-center i.fa-envelope {
  font-size: 17px;
  line-height: 38px;
}

.footer-distributed .footer-center p {
  display: inline-block;
  color: whitesmoke;
  vertical-align: middle;
  margin: 0;
}

.footer-distributed .footer-center p span {
  display: block;
  font-weight: normal;
  font-size: 14px;
  line-height: 2;
}

.footer-distributed .footer-center p a {
  color: black;
  text-decoration: none;
}

.footer-distributed .footer-right {
  width: 20%;
}

.footer-distributed .footer-company-about {
  line-height: 20px;
  color: #d1d1d8;
  font-size: 13px;
  font-weight: normal;
  margin: 0;
}

.footer-distributed .footer-company-about span {
  display: block;
  color: whitesmoke;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 20px;
}

.footer-distributed .footer-icons {
  margin-top: 25px;
}

.footer-distributed .footer-icons a {
  width: 35px;
  height: 35px;
  cursor: pointer;

  font-size: 20px;
  text-align: center;
  line-height: 35px;

  margin-right: 3px;
  margin-bottom: 5px;
}

@media (max-width: 880px) {
  .footer-distributed {
    font: bold 14px sans-serif;
  }

  .footer-distributed .footer-left,
  .footer-distributed .footer-center,
  .footer-distributed .footer-right {
    display: block;
    width: 100%;
    margin-bottom: 40px;
    text-align: center;
  }

  .footer-distributed .footer-center i {
    margin-left: 0;
  }
  .main {
    line-height: normal;
    font-size: auto;
  }
}
      
   </style>
  </head>
  <body>
  <div id="strip">

  </div>
  <div id="name">
    <img src="images/krishnawhite.jpg">
      <h1>Krshna & Me</h1>
  </div>

  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="padding-left: 120px;padding-right: 20px;">
        <li class="nav-item active" style="padding-right: 20px;">
          <a class="nav-link" href="#">HOME <span class="sr-only">(current)</span></a>
        </li>
        
        <li class="nav-item active dropdown"  style="padding-right: 20px;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            SHOP+
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
           


              
            <a class="dropdown-item" href="deity.php">Deities</a>
            <div class="dropdown-divider"></div>
            
         
          
            <a class="dropdown-item" href="#">Devotees</a>
            <div class="dropdown-divider"></div>
           
          
            <a class="dropdown-item" href="#">Dress Donation</a>
            
          

          </div>
        </li>
        <li class="nav-item active"  style="padding-right: 20px;">
          <a class="nav-link" href="#">ABOUT <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="#">CONTACT <span class="sr-only">(current)</span></a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </nav>

  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
     
      <div class="carousel-item active">
        <img src="images/homepageimg.jpg" class="d-block w-100" alt="...">
        
      </div>
      <div class="carousel-item">
        <img src="images/adronments image new.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="images/tag6.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="images/tag2.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="images/tag5.png" class="d-block w-100" alt="...">
      </div>
      
      
      
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


  <div id="offer1">
    <img src="images/offer1.jpg"style="width:100%;">
  </div>
 


  <div id="deity">
   
        <img src="images/tag3.jpg" style="margin-right: 30%;margin-left:30%;height:150px;width:40%;">    
   


        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <a href="images/pro1.jpg" data-toggle="lightbox" data-gallery="example-gallery"> <img class="design" src="images/pro1.jpg" style="float: left; margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="..."></a>
              <img class="design" src="images/pro2.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/pro3.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/pro4.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
            </div>
            <div class="carousel-item">
              <img class="design" src="images/pro5.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/pro6.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/pro2.jpg" style="float: left;margin-right:4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/pro9.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
            </div>
           
          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev" >
            <span class="carousel-control-prev-icon" aria-hidden="true" style="background-color: black;"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true" style="background-color: black;"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
        
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <a href="images/dev1.jpg" data-toggle="lightbox" data-gallery="example-gallery"> <img class="design" src="dev1.jpg" style="float: left; margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="..."></a>
              <img class="design" src="images/dev2.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/dev3.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/dev4.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
            </div>
            <div class="carousel-item">
              <img class="design" src="images/dev5.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/dev6.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/dev7.jpg" style="float: left;margin-right:4%;margin-left: 4%;" class="d-block w-23" alt="...">
              <img class="design" src="images/dev8.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
            </div>
           
          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev" >
            <span class="carousel-control-prev-icon" aria-hidden="true" style="background-color: black;"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true" style="background-color: black;"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
   
  </div>

  <div id="offer3">
    <img src="images/offer3.jpg"style="width:100%;">
  </div>


  <div id="donation">
   
    <img src="images/tag1.png" style="margin-right: 30%;margin-left:30%;height:150px;width:40%;">   
  
  
  
  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
  <div class="carousel-item active">
   <a href="images/don1.jpg" data-toggle="lightbox" data-gallery="example-gallery"> <img class="design" src="images/don1.jpg" style="float: left; margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="..."></a>
   <img class="design" src="images/don2.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
   <img class="design" src="images/don3.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
   <img class="design" src="images/don4.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
  </div>
  <div class="carousel-item">
   <img class="design" src="images/don5.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
   <img class="design" src="images/don6.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
   <img class="design" src="images/don7.jpg" style="float: left;margin-right:4%;margin-left: 4%;" class="d-block w-23" alt="...">
   <img class="design" src="images/don8.jpg" style="float: left;margin-right: 4%;margin-left: 4%;" class="d-block w-23" alt="...">
  </div>
  
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev" >
  <span class="carousel-control-prev-icon" aria-hidden="true" style="background-color: black;"></span>
  <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
  <span class="carousel-control-next-icon" aria-hidden="true" style="background-color: black;"></span>
  <span class="sr-only">Next</span>
  </a>
  </div>
  
  
  
  </div>

  <div id="offer2">
    <img src="images/offer2.jpg"style="width:100%;">
  </div>


<div id="aboutbg">
<div id="about">
  <img src="images/tag4.jpg" style="margin-right: 30%;margin-left:30%;height:130px;width:40%;margin-bottom: 50px;">
  
  <div class="row">
    
    <div class="col-sm-9">
      <p>Welcome to Divyshringar, a divine hub. We at Divyshringar aim to serve God, by serving men. We specialize in offering designer zardosi dresses for Bal Gopal, Radha Krishna and other deities; customised poshak and zardosi mukut mala, deities accessories and other spiritual items. We are also manufacturer and wholesaler of brass and ashtadhatu Idols of all the deities. Be it Laddu Gopal in his early days or be it Radha Krishna statue in Iskcon temple posture or Lord Shiva Idol in his meditation form, you just name it and we shall serve you with it paper writer online .

        Also, we have wide range of marble and wooden handicrafts, inclusive of deities statues, pooja items of paper mache and kundan work like pooja thali, chopra singhasan and rangoli. The collection of such products  and perfection of craftsmanship that you would find here is surely unbeatable.
        
        
        Whether you want to do online shopping for Radha Krishna, Laddu Gopal or any deity, we are the best online portal for you. All our products are designed and crafted with perfection by our artisans. We have the best artisans in the industry who work for us, to make the best dresses, accessories and ornaments for God. All these products are one of their kind and unique. We also offer Diwali, Janmashtami, Shivratri special packages. Our designers offer you with out of the box designs when it comes to Laddu Gopal Poshak, Radha Krishna Dress, Designer Lehnga Patka, etc. With our simple to surf website, you can find products easily and buy them with a few clicks and get them delivered at your doorsteps in the least possible time.</p>
    </div>
    <div class="col-sm-3">
      <img src="images/peacock.jpg" style="width: 350px;height:350px;">
    </div>
  </div>
 
     
    
    
  </div>
  
  
  
  </div>
</div>
<div id="contact">
<img id="k" src="images/krishnawhite.jpg">
<img id="s" src="images/strip.png">
<div id="end">
  <footer class="footer-distributed">
    <div class="footer-left">
      <h3>Krishna <span>&</span> Me</h3>
  
      <p class="footer-links">
        <a href="#">Home</a>
        ·
        <a href="#">About Us</a>
        ·
        <a href="#">Blog</a>
        ·
        <a href="#">Events</a>
        ·
        <a href="#">Projects</a>
        ·
        <a href="#">Contact</a>
      </p>
  
      <p class="footer-company-name">&copy; 2020</p>
    </div>
  
    <div class="footer-center">
      <!-- <div>
        <i class="fa fa-map-marker"></i>
        <p>
          <span>Anna Nagar slums,Rachna Nagar,Bhopal</span> Madhya Pradesh,
          India
        </p>
      </div> -->
  
      <div>
        <i class="fa fa-phone"></i>
        <p>+91 9837539999</p>
      </div>
  
      <div>
        <i class="fa fa-envelope"></i>
        <p>
          <a href="#" style="color: white;">krishnaandme@gmail.com</a>
        </p>
      </div>
    </div>
  
    <div class="footer-right">
      <p class="footer-company-about">
        <span>About Us</span>
        Aaroha is a youth organization which works for the upliftment of the
        underprivileged children.
      </p>
  
      <div class="footer-icons">
        <a href="https://www.facebook.com/aaroha.youthorg/">
          <img src="https://img.icons8.com/nolan/40/facebook-new.png"
        /></a>
        <a href="#"
          ><img src="https://img.icons8.com/nolan/40/twitter.png"
        /></a>
        <a href="https://www.facebook.com/aaroha.youthorg/"
          ><img src="https://img.icons8.com/nolan/40/instagram-new.png"
        /></a>
      </div>
    </div>
  </footer>
</div>
</div>
  

     <!-- AniJS core library -->
 <script src="https://anijs.github.io/lib/anijs/anijs-min.js"></script> 
  
 <!-- Include to use $addClass, $toggleClass or $removeClass -->
 <script src="https://anijs.github.io/lib/anijs/helpers/dom/anijs-helper-dom-min.js"></script>

 
 <script src="https://anijs.github.io/lib/anijs/helpers/scrollreveal/anijs-helper-scrollreveal-min.js"></script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>  
    <script>
        $(document).on('click', '[data-toggle="lightbox"]', function(event) {
                    event.preventDefault();
                    $(this).ekkoLightbox();
                });
    </script> 
  </body>
  </html>
